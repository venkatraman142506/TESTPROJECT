﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PalindromeChecker.Data;
using PalindromeChecker.ViewModel;
using AutoMapper;
using PalindromeChecker.Service;
using Microsoft.Extensions.Logging;

namespace PalindromeChecker.Controllers
{
    [Produces("application/json")]
    [Route("api/PalindromeChecker")]
    public class PalindromeCheckerController : Controller
    {
        private IPalindromeCheckerService _service;
        private ILogger<PalindromeCheckerController> _logger;

        public PalindromeCheckerController(IPalindromeCheckerService service, ILogger<PalindromeCheckerController> logger)
        {
            _service = service;
            _logger = logger;
        }

        [HttpGet("")]
        public IActionResult Get()
        {
            try
            {
                var listValidPalindrome = _service.GetAllValidPalindromes();
                return Ok(listValidPalindrome);
            }
            catch(Exception ex)
            {
                _logger.LogError($"Failed to retrieve: {ex}");
                return BadRequest("Unable to retrieve");
            }

            
        }

        [HttpPost("")]
        public IActionResult Post([FromBody] PalindromeViewModel palindromeViewModel)
        {
            if(ModelState.IsValid)
            {
                try
                {                  
                    _service.CheckAndAddPalindromeText(palindromeViewModel);
                    return Created($"api/PalindromeChecker/{palindromeViewModel.PalindromeText}", palindromeViewModel);
                }
                catch(Exception ex)
                {
                    _logger.LogError($"Failed to add: {ex}");
                    return BadRequest("Unable to add");
                }
            }
            else
            {
                _logger.LogWarning($"Failed to add: {ModelState}");
                return BadRequest(ModelState);
            }
           
        }

    }
}