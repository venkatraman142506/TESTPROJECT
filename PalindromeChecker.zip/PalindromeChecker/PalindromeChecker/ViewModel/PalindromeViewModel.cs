﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PalindromeChecker.ViewModel
{
    public class PalindromeViewModel
    {
        [Required]
        public string PalindromeText { get; set; }
        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
    }
}
