﻿using AutoMapper;
using PalindromeChecker.Data;
using PalindromeChecker.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace PalindromeChecker.Service
{
    public class PalindromeCheckerService : IPalindromeCheckerService
    {
        private IPalindromeCheckerRepository _repository;

        public PalindromeCheckerService(PalindromeCheckerRepository repository)
        {
            _repository = repository;
        }

        public IEnumerable<ValidPalindrome> GetAllValidPalindromes()
        {
            return _repository.GetAllValidPalindromes();
        }

        //need to await / async
        public void CheckAndAddPalindromeText(PalindromeViewModel palindromeViewModel)
        {
            if(IsPalindrome(palindromeViewModel.PalindromeText))
            {
                var validPalindrome = Mapper.Map<ValidPalindrome>(palindromeViewModel);
                _repository.AddValidPalindrome(validPalindrome);
            }
            else
            {
                var inValidPalindrome = Mapper.Map<InValidPalindrome>(palindromeViewModel);
                _repository.AddInValidPalindrome(inValidPalindrome);
            }

            
        }

        private bool IsPalindrome(string inputString)
        {
            Regex rgx = new Regex("[^a-zA-Z0-9 -]");
            string formattedString = rgx.Replace(inputString, ""); // to compare only alpha numeric chars

            return formattedString == new string(formattedString.Reverse().ToArray());
        }

    }
}
