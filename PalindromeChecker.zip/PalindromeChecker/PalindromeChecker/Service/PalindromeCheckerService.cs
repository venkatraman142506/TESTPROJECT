﻿using AutoMapper;
using PalindromeChecker.Data;
using PalindromeChecker.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace PalindromeChecker.Service
{
    public class PalindromeCheckerService : IPalindromeCheckerService
    {
        private IPalindromeCheckerRepository _repository;
        private IMapper _mapper;

        public PalindromeCheckerService(IPalindromeCheckerRepository repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        public IEnumerable<ValidPalindrome> GetAllValidPalindromes()
        {
            return _repository.GetAllValidPalindromes();
        }

        
        public bool CheckAndAddPalindromeText(PalindromeViewModel palindromeViewModel)
        {
            if (IsPalindrome(palindromeViewModel.PalindromeText))
            {
                var validPalindrome = _mapper.Map<ValidPalindrome>(palindromeViewModel);

                _repository.AddValidPalindrome(validPalindrome);
                return true;
            }
            else
            {
                return false;
            }
            //else
            //{
            //    var inValidPalindrome = _mapper.Map<InValidPalindrome>(palindromeViewModel);
            //    _repository.AddInValidPalindrome(inValidPalindrome);
            //}            
        }

        private bool IsPalindrome(string inputString)
        {
            Regex rgx = new Regex("[^a-zA-Z0-9-]");
            string formattedString = rgx.Replace(inputString, ""); // to compare only alpha numeric chars

            return formattedString.ToUpper() == new string(formattedString.Reverse().ToArray()).ToUpper();
        }

    }
}
