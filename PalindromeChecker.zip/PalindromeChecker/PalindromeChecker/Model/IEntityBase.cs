﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PalindromeChecker.Data
{
    public interface IEntityBase { int ID { get; set; } }
}
