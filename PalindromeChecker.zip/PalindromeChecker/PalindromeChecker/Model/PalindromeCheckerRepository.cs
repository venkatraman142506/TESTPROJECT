﻿using PalindromeChecker.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PalindromeChecker.Data
{
    public class PalindromeCheckerRepository : IPalindromeCheckerRepository
    {
        private PalindromeCheckerContext _context;

        public PalindromeCheckerRepository (PalindromeCheckerContext context)
        {
            _context = context;
        }

        public IEnumerable<ValidPalindrome> GetAllValidPalindromes()
        {
            return _context.ValidPalindrome.ToList();
        }

        //need to await / async
        public void AddValidPalindrome(ValidPalindrome validPalindrome)
        {
            _context.ValidPalindrome.Add(validPalindrome);
        }

        public void AddInValidPalindrome(InValidPalindrome inValidPalindrome)
        {
            _context.InValidPalindrome.Add(inValidPalindrome);
        }

        public async Task<bool> SaveChangesAsync()
        {
            return (await _context.SaveChangesAsync()) > 0;
        }
    }
}
