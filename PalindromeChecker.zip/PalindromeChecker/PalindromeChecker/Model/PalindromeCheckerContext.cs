﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;

namespace PalindromeChecker.Data
{
    public class PalindromeCheckerContext : DbContext
    {

        public PalindromeCheckerContext(DbContextOptions<PalindromeCheckerContext> options)
            : base(options)
        { }


        public DbSet<ValidPalindrome> ValidPalindrome { get; set; }
        public DbSet<InValidPalindrome> InValidPalindrome { get; set; }

        public virtual void Commit()
        {
            base.SaveChanges();
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
           // fluent api chained calls
            modelBuilder.Entity<ValidPalindrome>()
                .Property(t => t.PalindromeText)
                    .IsRequired();

            modelBuilder.Entity<InValidPalindrome>()
                .Property(t => t.PalindromeText)
                    .IsRequired();
        }

    }
}
