﻿using AutoMapper;
using PalindromeChecker.Data;
using PalindromeChecker.ViewModel;

namespace PalindromeChecker.Model
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<PalindromeViewModel, ValidPalindrome>();
            CreateMap<PalindromeViewModel, InValidPalindrome>();
        }

    }
}
