﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PalindromeChecker.Data
{
    public class InValidPalindrome : IEntityBase
    {
        public int ID { get; set; }
        public string PalindromeText { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
