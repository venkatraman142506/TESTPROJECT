﻿using PalindromeChecker.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PalindromeChecker.Data
{
    public interface IPalindromeCheckerRepository
    {
        IEnumerable<ValidPalindrome> GetAllValidPalindromes();
        void AddValidPalindrome(ValidPalindrome objValidPalindromes);
        void AddInValidPalindrome(InValidPalindrome objValidPalindromes);
        Task<bool> SaveChangesAsync();
    }
}
