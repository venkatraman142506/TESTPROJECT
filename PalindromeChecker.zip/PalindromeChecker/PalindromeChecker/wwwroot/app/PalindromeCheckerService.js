﻿(function () {
    'use strict';

    angular
        .module('app')
        .service('PalindromeCheckerService', PalindromeCheckerService);

    PalindromeCheckerService.$inject = ['$http'];

    function PalindromeCheckerService($http) {
        this.getValidPalindromes = getValidPalindromes;
        this.addPalindrome = addPalindrome;

        function getValidPalindromes() {
            return $http({
                method: 'GET',
                url: '/api/palindromeChecker'
            });

            //$http.get("/api/palindromeChecker").then(function(response){
            //    return response.data;
            //}, function () {
            //    return "Unable to retrieve Valid Palindromes";
            //});
            
        }
        function addPalindrome(palindrome) {
            return $http({
                method: 'POST',
                url: '/api/palindromeChecker',
                data: palindrome
            });
        }
    }
})();