﻿(function () {
    'use strict';

    angular
        .module('app')
        .service('PalindromeCheckerService', PalindromeCheckerService);

    PalindromeCheckerService.$inject = ['$http'];

    function PalindromeCheckerService($http) {
        this.getValidPalindromes = getValidPalindromes;
        this.addPalindrome = addPalindrome;

        function getValidPalindromes() {
            return $http({
                method: 'GET',
                url: '/api/palindromeChecker'
            });
           
        }
        function addPalindrome(palindrome) {
            return $http({
                method: 'POST',
                url: '/api/palindromeChecker',
                data: palindrome
            });
        }
    }
})();