﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('PalindromeCheckerController', PalindromeCheckerController);

    //PalindromeCheckerController.$inject = ['PalindromeCheckerService'];

    function PalindromeCheckerController($http) {

        var vm = this;
        vm.palindrome = "";

        vm.validPalindromes = [];

        vm.errorMessage = "";
                
        vm.addPalindrome = function () {

            vm.errorMessage = "";

            var palindrome = {
                palindromeText: vm.palindrome
            }

            $http({
                method: 'POST',
                url: '/api/palindromeChecker',
                data: palindrome
            }).then(function (response) {
                vm.validPalindromes.push(response.data);
                vm.palindrome = "";
            }, function (error) {
                vm.errorMessage = "Failed to save data: " + error.data;
            });

        }

        
        $http.get("/api/palindromeChecker").then(function(response){           
            angular.copy(response.data, vm.validPalindromes);
            }, function (error) {
                vn.errorMessage = "Failed to load data ";
            });
    }
})();
