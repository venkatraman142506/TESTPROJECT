﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('PalindromeCheckerController', PalindromeCheckerController);

    //PalindromeCheckerController.$inject = ['PalindromeCheckerService'];

    angular.module('app').directive('jsonText', function () {
        return {
            restrict: 'A',
            require: 'ngModel',
            link: function (scope, element, attr, ngModel) {
                function into(input) {
                    return JSON.parse(input);
                }
                function out(data) {
                    return JSON.stringify(data);
                }
                ngModel.$parsers.push(into);
                ngModel.$formatters.push(out);

            }
        };
    });


    function PalindromeCheckerController($http) {

        var vm = this;
        vm.palindrome = { };

        vm.validPalindromes = [];

        vm.errorMessage = "";
                
        vm.addPalindrome = function () {

            vm.errorMessage = "";

            var palindrome = {
                palindromeText: vm.palindrome
            }

            $http({
                method: 'POST',
                url: '/api/palindromeChecker',
                data: palindrome
            }).then(function (response) {
                vm.validPalindromes.push(response.data);
                vm.palindrome = { };
            }, function (error) {
                vm.errorMessage = "Failed to load data ";
            });

            //$http.post("/api/palindromeChecker", palindrome).then(function (response) {
            //    vm.validPalindromes.push(response.data);
            //    vm.palindrome = {};
            //}, function (error) {
            //    vm.errorMessage = "Failed to load data ";
            //});
        }




        $http.get("/api/palindromeChecker").then(function(response){           
            angular.copy(response.data, vm.validPalindromes);
            }, function (error) {
                vn.errorMessage = "Failed to save data ";
            });

        //function addPalindrome() {
        //    var Palindrome = {
        //        PalindromeText: vm.Palindrome.PalindromeText
        //    }

        //    TodoService.addPalindrome(Palindrome).then(function () {
        //        TodoService.getValidPalindromes().success(function (response) {
        //            vm.ValidPalindromes = response;
        //        });
        //    });
        //}

        //activate();

        //function activate() {
        //    PalindromeCheckerService.getValidPalindromes().then(function (data) {
        //        vm.validPalindromes = data;
        //    });
        //}
    }
})();
